#define kidForm1 1000
#define kidForm2 1001
#define kidForm3 1002
#define kidForm4 1003
#define kidForm5 1004
#define kidForm6 1005
#define kidForm7 1006
#define kidForm8 1007
#define kidForm9 1008
#define kidForm10 1009
#define kidForm11 1010
#define kidForm12 1011
#define kidFormLast 1011

#define kidOk 9999
#define kidTable 1000

#define kidAlert1 1000
#define kidMenu1 1000
#define kidHelp1 1000
#define kidHelp2 1001
#define kidBitmap 1000
